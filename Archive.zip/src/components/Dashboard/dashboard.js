import React, { Component } from 'react';

class Dashboard extends Component {
  render() {
    return (
      <div >
          this is dash board
      </div>
    );
  }
}

export default Dashboard;
