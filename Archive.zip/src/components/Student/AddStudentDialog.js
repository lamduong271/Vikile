import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import classNames from 'classnames';
import { withStyles } from '@material-ui/core/styles';
import MenuItem from '@material-ui/core/MenuItem';
import TextField from '@material-ui/core/TextField';
import AddStudentButton from './AddStudentButton';
import withMobileDialog from '@material-ui/core/withMobileDialog';

const styles = theme => ({
    container: {
      display: 'flex',
      flexWrap: 'wrap',
    },
    textField: {
      marginLeft: theme.spacing.unit,
      marginRight: theme.spacing.unit
    },
    dense: {
      marginTop: 16,
    },
    menu: {
      width: 200,
    },
  });
  
class AddStudentDialog extends Component {
    constructor(props) {
        super(props)
        this.state = {
            open: false,
            first_name:'',
            last_name:''
        };
    }
  handleClickOpen = () => {
    this.setState({ open: true });
  };

  handleClose = () => {
    this.setState({ open: false });
  };

  

  render() {
    const { classes } = this.props;
    const {first_name, last_name} = this.state;

    return (
      <div>
        <AddStudentButton variant="outlined" color="primary" openAddDialog={()=>this.handleClickOpen()}>
        </AddStudentButton>
        <Dialog
          open={this.state.open}
          onClose={this.handleClose}
          aria-labelledby="responsive-dialog-title"
        >
          <h6>Add Student</h6>
          <form className={classes.container} noValidate autoComplete="off">
          <TextField
            id="standard-textarea"
            label="First name"
            placeholder="Placeholder"
            multiline
            className={classes.textField}
            value={first_name}
            onChange={(event) => this.setState({first_name: event.target.value})}
            margin="normal"
            />
            
            <TextField
            id="standard-textarea"
            label="Last name"
            placeholder="Placeholder"
            multiline
            className={classes.textField}
            value={last_name}
            onChange={(event) => this.setState({last_name: event.target.value})}
            margin="normal"
            />
            
            </form>
        </Dialog>
      </div>
    );
  }
}

AddStudentDialog.propTypes = {
    classes: PropTypes.object.isRequired,
  };
  
  export default withStyles(styles)(withMobileDialog()(AddStudentDialog));